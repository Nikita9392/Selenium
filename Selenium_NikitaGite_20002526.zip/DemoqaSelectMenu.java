package assignments;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class DemoqaSelectMenu {

	public static void main(String[] args) throws InterruptedException {
		 WebDriver driver=BrowserFactory.launchBrowser("chrome");
	       driver.manage().window().maximize();
	       driver.get("https://demoqa.com/selectmenu/");
     WebElement speed=driver.findElement(By.xpath("//span[@id='speed-button']"));
    speed.click();
     speed.sendKeys(Keys.ARROW_DOWN);
     speed.sendKeys(Keys.ENTER);
       WebElement file=driver.findElement(By.id("files-button"));
       file.click();
       file.sendKeys(Keys.ARROW_DOWN);
     
       file.sendKeys(Keys.ENTER);
       
       WebElement number=driver.findElement(By.id("number-button"));
       number.click();
       number.sendKeys(Keys.ARROW_DOWN);
       number.sendKeys(Keys.ARROW_DOWN);
       number.sendKeys(Keys.ARROW_DOWN);
       number.sendKeys(Keys.ENTER);
       Thread.sleep(1000);
       
       WebElement s_button=driver.findElement(By.id("salutation-button"));
       s_button.click();
       s_button.sendKeys(Keys.ARROW_DOWN);
       s_button.sendKeys(Keys.ARROW_DOWN);  s_button.sendKeys(Keys.ARROW_DOWN);
       s_button.sendKeys(Keys.ARROW_DOWN);
       s_button.sendKeys(Keys.ARROW_DOWN);
     
       s_button.sendKeys(Keys.ENTER); 
       
	}

}
