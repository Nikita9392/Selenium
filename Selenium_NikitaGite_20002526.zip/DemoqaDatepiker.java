package assignments;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class DemoqaDatepiker {

	public static void main(String[] args) {
		 WebDriver driver=BrowserFactory.launchBrowser("chrome");
	       driver.manage().window().maximize();
	       String dateTime ="27/03/1992";
	       driver.get("https://demoqa.com/datepicker/");
              driver.findElement(By.id("datepicker")).click();
              
          WebElement Previous=driver.findElement(By.xpath("//span[text()='Prev']"));
         

	}

}
