package assignments;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class DemoqaContactForm {

	public static void main(String[] args) throws InterruptedException {
		 WebDriver driver=BrowserFactory.launchBrowser("chrome");
	       driver.manage().window().maximize();
	      driver.get("https://demoqa.com/html-contact-form/");
	       driver.findElement(By.className("firstname")).sendKeys("Nikita");
           driver.findElement(By.id("lname")).sendKeys("Geete");
	       driver.findElement(By.name("country")).sendKeys("india");
	     driver.findElement(By.id("subject")).sendKeys("Automation Testing");
	         String parent= driver.getWindowHandle();
	  String selectLinkOpeninNewTab = Keys.chord(Keys.CONTROL,Keys.RETURN); 
	     driver.findElement(By.linkText("Google Link")).sendKeys(selectLinkOpeninNewTab);
	    //  driver.switchTo().window("parent");
	     
	     
	      //String selectLinkOpeninNewTab1 = Keys.chord(Keys.CONTROL,Keys.RETURN); 
		    // driver.findElement(By.partialLinkText("Google Link is")).sendKeys(selectLinkOpeninNewTab1);
		      //driver.switchTo().window("https://demoqa.com/html-contact-form/");
	     
	     
	     
	     driver.findElement(By.cssSelector("input[value='Submit']")).click();
	
	
	
	}

}