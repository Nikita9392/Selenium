
package assignments;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class DemoqaControlGroup {
	public static void main(String[] args) throws InterruptedException {
		 WebDriver driver=BrowserFactory.launchBrowser("chrome");
	       driver.manage().window().maximize();
	       driver.get("https://demoqa.com/controlgroup/");
	      WebElement car_type= driver.findElement(By.id("car-type-button"));
	      car_type.click();
	      car_type.sendKeys(Keys.ARROW_DOWN);
	      car_type.sendKeys(Keys.ENTER);
	      
	      
	     WebElement standard=driver.findElement(By.xpath("//span[@id='car-type-button']/following-sibling::label[text()='Standard']"));
	     if(standard.isSelected())
	     {
	    	 System.out.println("already selected");
	     }
	     else
	    	 standard.click();
driver.findElement(By.xpath("//span[@id='car-type-button']/following-sibling::label[text()='Insurance']")).click();
WebElement number=driver.findElement(By.xpath("//a[@tabindex='-1']"));
       
        number.click();number.click();
        driver.findElement(By.xpath("(//button[text()='Book Now!'])[1]")).click();
        

}}
