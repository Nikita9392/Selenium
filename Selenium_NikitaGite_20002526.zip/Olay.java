package assignments;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Olay {
	WebDriver driver;
	@BeforeMethod
	public void launch()
	{
        driver=BrowserFactory.launchBrowser("chrome");
	       driver.manage().window().maximize();
	}
	@Test
	public void navi()
	{
	driver.get("https://www.olay.co.uk/en-gb/createprofilepage");
	     
       driver.findElement(By.xpath("//input[@data-key='emailAddress']")).sendKeys("nukkinikki9@gmail.com");
       driver.findElement(By.xpath("//input[@data-key='newPassword']")).sendKeys("abc@1234");
       driver.findElement(By.xpath("(//input[@type='password'])[2]")).sendKeys("abc@1234");
       WebElement ele=driver.findElement(By.id("phdesktopbody_0_grs_consumer[birthdate][day]"));
       Select sel=new Select(ele);
       sel.selectByVisibleText("27");
       WebElement ele1=driver.findElement(By.id("phdesktopbody_0_grs_consumer[birthdate][month]"));
       Select sel1=new Select(ele1);
    		   
    		 sel1.selectByVisibleText("3");
    		   
       
       
       WebElement ele2=driver.findElement(By.id("phdesktopbody_0_grs_consumer[birthdate][year]"));
       Select sel2=new Select(ele2);
	   
		 sel2.selectByVisibleText("1992");
		   WebElement submit=driver.findElement(By.id("phdesktopbody_0_submit"));
		   JavascriptExecutor je=(JavascriptExecutor)driver;
		  String jecode="arguments[0].scrollIntoView(true)";
		  je.executeScript(jecode, submit);
		  submit.click();
		  
		   
 
}

}
