package assignments;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Demoqa {

	public static void main(String[] args) {
       WebDriver driver=BrowserFactory.launchBrowser("chrome");
       driver.manage().window().maximize();
       driver.get("https://demoqa.com/selectable/");
       WebElement selectable=driver.findElement(By.id("selectable"));
        List<WebElement> items=selectable.findElements(By.cssSelector("ol[id=\"selectable\"]>li"));
                      int count=items.size();
                      System.out.println("the total items are ="+ count);
                      for(int i=0;i<count;i++)
                      {
                    	  WebElement list=items.get(i);
                    	               list.click();
                    	            String  name=list.getText();
                    	            System.out.println(name);
                      }
       
	}

}
