package assignments;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class DemoqaDropable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 WebDriver driver=BrowserFactory.launchBrowser("chrome");
	       driver.manage().window().maximize();
	       driver.get("https://demoqa.com/droppable/");
	       Actions act= new Actions(driver);
	       WebElement source=driver.findElement(By.xpath("//p[text()='Drag me to my target']"));
	       WebElement target=driver.findElement(By.id("droppable"));
	       act.dragAndDrop(source, target).perform();
	       String actualText=source.getText();
	      String expectedText="Drag me to my target";
	       if(actualText.equals(expectedText))
	       {
	    	   System.out.println("text is verified");
	       }
	}

}
