package assignments;

import java.time.LocalDate;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class MakeMyTrip {

	public static void main(String[] args) throws InterruptedException {
		 WebDriver driver=BrowserFactory.launchBrowser("chrome");
	       driver.manage().window().maximize();
	        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	      driver.get("https://www.makemytrip.com/");
	    driver.findElement(By.xpath("//li[@class='selected']/span[@class='tabsCircle appendRight5']")).click();
	    WebElement from=driver.findElement(By.id("fromCity"));
	       from.click();
	       from.sendKeys("pune");
	      	    from.findElement(By.xpath("//div[text()='PNQ']")).click();
	      	    
	      	    WebElement to=driver.findElement(By.id("toCity"));
	      	      to.sendKeys("indore");
	      	    to.findElement(By.xpath("//div[text()='IDR']")).click();
      
	      	   
	      	    driver.findElement(By.xpath("//span[text()='DEPARTURE']")).click();
      
	      String depxp="//div[starts-with(text(),'June')]/parent::div/following-sibling::div//p[text()='20']";
    		   
	      driver.findElement(By.xpath(depxp)).click();  
    		   driver.findElement(By.xpath("//a[text()='Search']")).click();
       
       driver.findElement(By.xpath("//span[@class='down sort-arrow']")).click();
       driver.findElement(By.xpath("(//button[text()='Book Now'])[1]")).click();
                              
       
	}

}
